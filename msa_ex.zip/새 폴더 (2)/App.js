import axios from "axios";
import {useState} from "react";
import './App.css';

function App() {
  const [inputs, setInputs] = useState({id:'', pwd:'', type:''});
  const {id, pwd, type} = inputs;
  const onChange = (e) => {//e: 방금 발생한 이벤트 객체
    const {name, value} = e.target;
    setInputs({
      ...inputs,
      [name]:value
    })
  }
  const login = () => {
    axios.post('http://13.125.209.49:8081/login',{},{params:{id:id,pwd:pwd}})
    .then(function(res){     //res.status:응답의 상태값 / res.data: 응답 값
      if(res.status===200){
        if(res.data.flag){
          alert('로그인 성공');
          alert(res.data['token']);
          document.cookie = "token="+res.data.token;
          
        }else{
          alert('로그인 실패');
        }
      }else{
        alert('error');
      }
    })
  }
  const logout = () => {
    document.cookie = "token=";
  }
  const join = () => {
    axios.post('http://13.125.209.49:8081/join',{},{params:{id:id,pwd:pwd,type:type}})
    .then(function(res){     //res.status:응답의 상태값 / res.data: 응답 값
      if(res.status===200){
        if(res.data.flag){
          alert('회원가입 성공/id:'+res.data.dto.id);
          
        }else{
          alert('회원가입 실패');
        }
      }else{
        alert('error');
      }
    })
  }
  const addinfo = () => {
    let token = "";
    if(!document.cookie.includes("token")){
      alert('로그인 하시오');
      return;
    }else{
      token = document.cookie.split("token=")[1].split(";")[0];
      if(token==""){
        alert('로그인 하시오');
        return;
      }
    }
    
    axios.post('http://13.124.6.100:8082/mems',{},{params:{id:id,name:pwd,email:type},headers:{'token':token}})
    .then(function(res){     //res.status:응답의 상태값 / res.data: 응답 값
      if(res.status===200){
        if(res.data.flag){
          alert('정보입력 성공');
          alert("name:"+res.data.dto.name);
          alert("email:"+res.data.dto.email);
        }else{
          alert('정보저장 실패');
        }
      }else{
        alert('error');
      }
    })
  }
  const info = () => {
    let token = "";
    if(!document.cookie.includes("token")){
      alert('로그인 하시오');
      return;
    }else{
      token = document.cookie.split("token=")[1].split(";")[0];
      if(token==""){
        alert('로그인 하시오');
        return;
      }
    }
    
    axios.get('http://13.124.6.100:8082/mems',{headers: {'token':token}})
    .then(function(res){     //res.status:응답의 상태값 / res.data: 응답 값
      if(res.status===200){
        if(res.data.flag){
          alert(res.data.dto.id);
          alert(res.data.dto.name);
          alert(res.data.dto.email);
        }else{
          alert('정보읽기 실패');
        }
      }else{
        alert('error');
      }
    })
  }
  return (
    <div className="App">
      <h3>로그인/회원가입</h3>
      id:<input type="text" name="id" onChange={onChange} value={id}/><br/>
      pwd/name:<input type="text" name="pwd" onChange={onChange} value={pwd}/><br/>
      type/email:<input type="text" name="type" onChange={onChange} value={type}/><br/>
      <button onClick={join}>회원가입</button><br/>
      <button onClick={login}>로그인</button><br/>
      <button onClick={info}>내정보</button><br/>
      <button onClick={addinfo}>정보추가</button><br/>
      <button onClick={logout}>로그아웃</button><br/>
      <div id="res"></div>
    </div>
  );
}

export default App;
